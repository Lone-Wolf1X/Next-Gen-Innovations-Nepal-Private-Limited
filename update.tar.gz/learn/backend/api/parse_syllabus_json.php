<?php
// Script to parse the JSON and seed the database locally via PHP
$json_content = file_get_contents('rbb-level5-complete-syllabus-structure.json');
$syllabus = json_decode($json_content, true);

// Include config (which contains the live DB credentials since it was copied there)
require_once 'config.php';
$pdo = getDbConnection();

try {
    // 1. Ensure Category exists
    $stmt = $pdo->prepare("SELECT id FROM gb_categories WHERE name = ?");
    $stmt->execute(['Banking']);
    $cat_result = $stmt->fetch();
    
    if ($cat_result) {
        $category_id = $cat_result['id'];
    } else {
        $stmt = $pdo->prepare("INSERT INTO gb_categories (name, status) VALUES (?, ?)");
        $stmt->execute(['Banking', 'active']);
        $category_id = $pdo->lastInsertId();
    }

    // 2. Add the Exams
    $exams_to_insert = [
        "RBB Level 5 - Admin" => $syllabus['organization'] . " - " . $syllabus['exam_name'] . " (Admin)",
        "RBB Level 5 - Cash" => $syllabus['organization'] . " - " . $syllabus['exam_name'] . " (Cash)"
    ];
    
    $exam_ids = [];
    foreach ($exams_to_insert as $title => $desc) {
        $stmt = $pdo->prepare("SELECT id FROM gb_exams WHERE title = ?");
        $stmt->execute([$title]);
        $result = $stmt->fetch();
        if ($result) {
            $exam_ids[$title] = $result['id'];
        } else {
            // Note: Schema has no description column for gb_exams, so we skip $desc
            $stmt = $pdo->prepare("INSERT INTO gb_exams (category_id, title, status) VALUES (?, ?, ?)");
            $stmt->execute([$category_id, $title, 'active']);
            $exam_ids[$title] = $pdo->lastInsertId();
        }
    }
            
    // 3. Create MCQ sets based on sections
    $admin_id = $exam_ids["RBB Level 5 - Admin"];
    $cash_id = $exam_ids["RBB Level 5 - Cash"];
    
    foreach ($syllabus['phases'] as $phase) {
        foreach ($phase['papers'] as $paper) {
            if (!isset($paper['sections'])) continue;
            
            foreach ($paper['sections'] as $section) {
                $set_title = $paper['paper_name'] . " - " . $section['section_name'];
                
                // Decide which exam this belongs to
                $target_exam_id = $admin_id;
                if (strpos($paper['paper_name'], 'Cash') !== false) {
                    $target_exam_id = $cash_id;
                }
                
                // Create the set (set_date is required)
                $stmt = $pdo->prepare("INSERT INTO gb_mcq_sets (exam_id, title, set_date, status) VALUES (?, ?, CURDATE(), ?)");
                $stmt->execute([$target_exam_id, $set_title, 'PUBLISHED']);
                $set_id = $pdo->lastInsertId();
                
                // Generate some dummy questions based on topics for now
                if (!isset($section['topics'])) continue;
                
                $topic_count = 0;
                foreach ($section['topics'] as $topic) {
                    if ($topic_count >= 2) break; // limit to 2 per section
                    
                    $q_text = "What is a key concept of: " . substr($topic, 0, 80) . "...?";
                    $exp = "This is an automated placeholder for " . substr($topic, 0, 40) . "...";
                    
                    $stmt = $pdo->prepare("INSERT INTO gb_questions 
                        (set_id, question_text, option_a, option_b, option_c, option_d, correct_option, explanation, exam_tip)
                        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
                    
                    $stmt->execute([
                        $set_id, 
                        $q_text,
                        "Option A", "Option B", "Option C", "Option D",
                        "A", 
                        $exp,
                        "Review syllabus!"
                    ]);
                    $topic_count++;
                }
            }
        }
    }

    echo "Successfully parsed syllabus JSON and seeded into live database!\n";

} catch (Exception $e) {
    echo "Error: " . $e->getMessage() . "\n";
}
?>
